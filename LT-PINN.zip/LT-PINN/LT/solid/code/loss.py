
import os
import torch
import numpy as np


# PDE loss
class PDELoss(torch.nn.Module):
    def __init__(self,nn_fun,Lx_min,Lx_max,Ly_min,Ly_max,miu):
        super().__init__()
        self.fun = nn_fun
        self.Lx_min = Lx_min
        self.Lx_max = Lx_max
        self.Ly_min = Ly_min
        self.Ly_max = Ly_max
        self.miu = miu
        

    def forward(self, X):
        
        x = X[:,0:1]
        y = X[:,1:2]
        X = torch.cat([x,y],dim=1) 
        
        Y_pred = self.fun(X) 
    
        u = Y_pred[:,0:1]
        v = Y_pred[:,1:2]
     
        u_x = torch.autograd.grad(u,x,grad_outputs=torch.ones_like(u),create_graph=True,retain_graph=True)[0]
        u_y = torch.autograd.grad(u,y,grad_outputs=torch.ones_like(u),create_graph=True,retain_graph=True)[0]
        v_x = torch.autograd.grad(v,x,grad_outputs=torch.ones_like(v),create_graph=True,retain_graph=True)[0]
        v_y = torch.autograd.grad(v,y,grad_outputs=torch.ones_like(v),create_graph=True,retain_graph=True)[0]
        
        exx = u_x
        eyy = v_y
        exy = 0.5*(u_y+v_x)
        
        oxx =  (exx+self.miu*eyy) / (1-self.miu**2)
        oyy = (eyy+self.miu*exx) / (1-self.miu**2)
        oxy =  exy / (1+self.miu) 

        oxx_x = torch.autograd.grad(oxx,x,grad_outputs=torch.ones_like(oxx),create_graph=True,retain_graph=True)[0]
        oxy_x = torch.autograd.grad(oxy,x,grad_outputs=torch.ones_like(oxy),create_graph=True,retain_graph=True)[0]
        oxy_y = torch.autograd.grad(oxy,y,grad_outputs=torch.ones_like(oxy),create_graph=True,retain_graph=True)[0]
        oyy_y = torch.autograd.grad(oyy,y,grad_outputs=torch.ones_like(oyy),create_graph=True,retain_graph=True)[0]
        
        eq1 = oxx_x + oxy_y
        eq2 = oxy_x + oyy_y
        
        # add cylinder weight mask
        X_center = (self.Lx_max-self.Lx_min+2)*torch.sigmoid(self.fun.X_center.weight)+(self.Lx_min-1)
        Y_center = (self.Ly_max-self.Ly_min+2)*torch.sigmoid(self.fun.Y_center.weight)+(self.Ly_min-1)
        
        dist = torch.sqrt((x - X_center)**2 + (y - Y_center)**2)
        
        radius = 0.5
        k = 100
        mask = 1 / (1 + torch.exp(-k * (dist - radius)))
        
        eq1 = mask * eq1 
        eq2 = mask * eq2

        output1 = torch.sum(torch.square(eq1))
        output2 = torch.sum(torch.square(eq2))


        output = (output1 + output2) / (2*len(eq1))
        
        return output


# Boundary loss
class BCLoss(torch.nn.Module):
    def __init__(self,nn_fun):
        super().__init__()
        self.fun = nn_fun

    def forward(self, X):
        
        x = X[:,0:1]
        y = X[:,1:2]
        X = torch.cat([x,y],dim=1) 
        
        Y_pred = self.fun(X) 
    
        u = Y_pred[:,0:1]
        v = Y_pred[:,1:2]

        output1 = torch.sum(torch.square(u))
        output2 = torch.sum(torch.square(v))        

        output = (output1 + output2) / (2*len(u))
        
        return output

# Supervise Data Loss
class DataLoss(torch.nn.Module):

    def __init__(self,nn_fun):
        super().__init__()
        self.fun = nn_fun

    def forward(self, X, Y_true):

        Y_pred = self.fun(X) 
              
        r0 = Y_pred[:,0] - Y_true[:,0]
        r1 = Y_pred[:,1] - Y_true[:,1]
    
        r0 = torch.sum(torch.square(r0))
        r1 = torch.sum(torch.square(r1))

        e0 = torch.sqrt(r0/torch.sum(torch.square(Y_true[:,0])))
        e1 = torch.sqrt(r1/torch.sum(torch.square(Y_true[:,1])))

   
        output = (r0 + r1) / (2*len(X))
        
        monitor = (e0 + e1)/2

        return output, monitor
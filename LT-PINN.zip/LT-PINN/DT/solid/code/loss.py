
import os
import torch
import numpy as np


# PDE loss
class PDELoss(torch.nn.Module):
    def __init__(self,nn_fun,miu):
        super().__init__()
        self.fun = nn_fun
        self.miu = miu

        

    def forward(self, X):
        
        x = X[:,0:1]
        y = X[:,1:2]
        X = torch.cat([x,y],dim=1) 
        
        Y_pred = self.fun(X) 
        u = Y_pred[:,0:1]
        v = Y_pred[:,1:2]
           
        dist = Y_pred[:,2:3]
        
        # add density mask
        k = 10
        mask = 1 / (1 + torch.exp(-k * dist))

        u_x = torch.autograd.grad(u,x,grad_outputs=torch.ones_like(u),create_graph=True,retain_graph=True)[0]
        u_y = torch.autograd.grad(u,y,grad_outputs=torch.ones_like(u),create_graph=True,retain_graph=True)[0]
        v_x = torch.autograd.grad(v,x,grad_outputs=torch.ones_like(v),create_graph=True,retain_graph=True)[0]
        v_y = torch.autograd.grad(v,y,grad_outputs=torch.ones_like(v),create_graph=True,retain_graph=True)[0]
        

        exx = u_x
        eyy = v_y
        exy = 0.5*(u_y+v_x)
        
        oxx =  (exx+self.miu*eyy) / (1-self.miu**2)
        oyy = (eyy+self.miu*exx) / (1-self.miu**2)
        oxy =  exy / (1+self.miu) 

        oxx_x = torch.autograd.grad(oxx,x,grad_outputs=torch.ones_like(oxx),create_graph=True,retain_graph=True)[0]
        oxy_x = torch.autograd.grad(oxy,x,grad_outputs=torch.ones_like(oxy),create_graph=True,retain_graph=True)[0]
        oxy_y = torch.autograd.grad(oxy,y,grad_outputs=torch.ones_like(oxy),create_graph=True,retain_graph=True)[0]
        oyy_y = torch.autograd.grad(oyy,y,grad_outputs=torch.ones_like(oyy),create_graph=True,retain_graph=True)[0]
        
        
        eq1 = mask * (oxx_x + oxy_y) + 0.001*(1-mask)*u
        eq2 = mask * (oxy_x + oyy_y) + 0.001*(1-mask)*v


        output1 = torch.sum(torch.square(eq1))
        output2 = torch.sum(torch.square(eq2))

        output = (output1 + output2 ) / (2*len(eq1))
        
        return output



# Supervise Data Loss

class DataLoss(torch.nn.Module):

    def __init__(self,nn_fun):
        super().__init__()
        self.fun = nn_fun

    def forward(self, X, Y_true):

        Y_pred = self.fun(X) 
              
        r0 = Y_pred[:,0] - Y_true[:,0]
        r1 = Y_pred[:,1] - Y_true[:,1]
    
        r0 = torch.sum(torch.square(r0))
        r1 = torch.sum(torch.square(r1))

        e0 = torch.sqrt(r0/torch.sum(torch.square(Y_true[:,0])))
        e1 = torch.sqrt(r1/torch.sum(torch.square(Y_true[:,1])))

        output = (r0 + r1) / (2*len(X))
        
        monitor = (e0 + e1)/2

        return output, monitor
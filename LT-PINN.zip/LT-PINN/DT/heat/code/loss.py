
import os
import torch
import numpy as np


# PDE loss
class PDELoss(torch.nn.Module):
    def __init__(self,nn_fun):
        super().__init__()
        self.fun = nn_fun

        

    def forward(self, X):
        
        x = X[:,0:1]
        y = X[:,1:2]
        X = torch.cat([x,y],dim=1) 
        
        Y_pred = self.fun(X)  
        u = Y_pred[:,0:1]
           
        dist = Y_pred[:,1:2]
        
        # add density mask
        k = 10
        mask = 1 / (1 + torch.exp(-k * dist))

        u_x = torch.autograd.grad(u,x,grad_outputs=torch.ones_like(u),create_graph=True,retain_graph=True)[0]
        u_y = torch.autograd.grad(u,y,grad_outputs=torch.ones_like(u),create_graph=True,retain_graph=True)[0]
        u_xx = torch.autograd.grad(u_x,x,grad_outputs=torch.ones_like(u_x),create_graph=True,retain_graph=True)[0]
        u_yy = torch.autograd.grad(u_y,y,grad_outputs=torch.ones_like(u_y),create_graph=True,retain_graph=True)[0]

        eq1 = mask*(u_xx + u_yy) 

        output = torch.sum(torch.square(eq1)) / len(eq1)

        
        return output



# Supervise Data Loss


class DataLoss(torch.nn.Module):

    def __init__(self,nn_fun):
        super().__init__()
        self.fun = nn_fun

    def forward(self, X, Y_true):

        Y_pred = self.fun(X) 
              
        r = Y_pred[:,0] - Y_true[:,0]

        r = torch.sum(torch.square(r))
    
        e = torch.sqrt(r/torch.sum(torch.square(Y_true[:,0])))

        output = r  / len(X)

        return output, e
    
    

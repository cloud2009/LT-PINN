# import tools
import os
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import csv
import math
import matplotlib.pyplot as plt
import time
import loss
import NeuralNetwork


## set global parameters
device = torch.device("cuda:0")
torch.manual_seed(20231028)
torch.set_default_dtype(torch.float32)


def main():

    # read data
    def load_data(filename):
        data_pd = pd.read_csv(filename, encoding='gbk',header=None)
        data = np.array(data_pd)
        return data[1:,:].copy().astype(float)
    
    data = load_data('../../../data/heat_128x128.csv')
    
    Lx_max = 0
    Lx_min = 0
    Ly_max = 0
    Ly_min = 0
    

    data_xy = data[:,0:2]
    data_xy[:,0] = data_xy[:,0]+7.5
    data_u = data[:,3:]-273 # normalize to 273K
    x_temp = data_xy[:,0]
    y_temp = data_xy[:,1]   
    idx = (x_temp<=1.1) & (x_temp>=-1.1) & (y_temp<=Ly_max+1.1) & (y_temp>=Ly_min-1.1)   
    x_all = data_xy[idx]
    y_all = data_u[idx]

    # test point
    x_temp = x_all[:,0]
    y_temp = x_all[:,1]
    idx = (x_temp<=1) & (x_temp>=-1) & (y_temp<=Ly_max+1) & (y_temp>=Ly_min-1)
    x_test = x_all[idx]
    y_test = y_all[idx]
    X_test = torch.tensor(x_test,dtype=torch.float32,device=device)
    Y_test = torch.tensor(y_test,dtype=torch.float32,device=device)
    
    # supervise point
    idx = np.random.choice(len(x_test),int(0.1*len(x_test)),replace=False)
    x_sup = x_test[idx]
    y_sup = y_test[idx]
    X_sup = torch.tensor(x_sup,dtype=torch.float32,device=device)
    Y_sup = torch.tensor(y_sup,dtype=torch.float32,device=device)

    # internal collocation point
    num_points_unit = 60
    num_points_x = int((Lx_max-Lx_min+2)*num_points_unit)  
    num_points_y = int((Ly_max-Ly_min+2)*num_points_unit) 
    x = np.linspace(Lx_min-1, Lx_max+1, num_points_x)
    y = np.linspace(Ly_min-1, Ly_max+1, num_points_y)
    X, Y = np.meshgrid(x, y)
    x_internal = np.stack((X.flatten(), Y.flatten()), axis=1)
    X_internal = torch.tensor(x_internal,dtype=torch.float32,device=device)
    X_internal.requires_grad = True
    
    print('test:',X_test.shape,Y_test.shape,'sup:',X_sup.shape,Y_sup.shape,'Internal:',X_internal.shape)
    
    
    # define trainable network 
    nn_fun = NeuralNetwork.MyNet(2,2,256,4)
    nn_fun = nn_fun.cuda()
    
    # load ckp
    try:
        load_param = torch.load('../checkpoint/nn_fun_params')
        nn_fun.load_state_dict(load_param)
    except:
        print('no saved network')
        
    train_parameters =  list(nn_fun.parameters())
        
    # define optimizer  
    optimizer = torch.optim.Adam(lr=1e-4,params=train_parameters)
    try:
        load_param = torch.load('../checkpoint/opt_params')
        optimizer.load_state_dict(load_param)
    except:
        print('no saved opt')

    # define loss

    dataLoss = loss.DataLoss(nn_fun)
    pdeLoss = loss.PDELoss(nn_fun)
  


    # train 
    wData = 1e4
    wEq = 1.0
    loss_sup = 0.0
    loss_eq = 0.0
    loss_test = 0.0

    
    for epoch in range(1,400001):
        
        time0 = time.time()
        
        
        # supervise loss
        loss_sup,_ = dataLoss(X_sup,Y_sup)
        loss_sup =  wData * (loss_sup)
        loss_sup.backward()
        
        # equation loss            
        loss_eq = wEq * pdeLoss(X_internal)
        loss_eq.backward()
        
        # test monitor
        with torch.no_grad():
            loss_test,monitor_test = dataLoss(X_test,Y_test)

        optimizer.step()        
        optimizer.zero_grad()
        loss_total = loss_sup + loss_eq 

        time1 = time.time()
        

        
        if epoch % 100 == 0:
            print('epoch:',epoch,'loss:',float(loss_total),'loss_sup:',float(loss_sup),'loss_eq:',float(loss_eq),'loss_test:',float(loss_test),'monitor_test:',float(monitor_test),time1-time0)
        
        if epoch % 1000 == 0:
            loss_log = [epoch,float(loss_total),float(loss_sup),float(loss_eq),float(loss_test),float(monitor_test)]
            with open('../checkpoint/loss_log.csv', 'a') as file:
                writer = csv.writer(file)
                writer.writerow(loss_log)

        if epoch % 1000 == 0:
            torch.save(nn_fun.state_dict(),'../checkpoint/nn_fun_params')
            torch.save(optimizer.state_dict(),'../checkpoint/opt_params')

        if epoch % 100000 == 0:
            torch.save(nn_fun.state_dict(),'../checkpoint/nn_fun_'+str(epoch))
            torch.save(optimizer.state_dict(),'../checkpoint/opt_params_'+str(epoch))

      
 
         
if __name__ == '__main__':
    
    main()

